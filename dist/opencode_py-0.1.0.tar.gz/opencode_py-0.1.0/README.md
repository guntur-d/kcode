# opencode-py — Python 3.8 port of opencode

Minimal, dependency-free (stdlib-only) AI coding agent inspired by
https://github.com/anomalyco/opencode , with optional
[PyTermGUI](https://github.com/bczsalba/pytermgui) TUI.

> PyTermGUI `requires-python >=3.8`, deps only `wcwidth + typing_extensions` —
> while modern Textual needs `>=3.9` (+ rich, pygments, markdown-it, platformdirs,
> optional tree-sitter on 3.10+). So **PyTermGUI is the easier choice for
> Python 3.8 / Windows Server 2016**.

## Install (Win2016 + Python 3.8)

```bat
py -3.8 -m pip install -r requirements.txt
rem interactive setup -> writes %USERPROFILE%\.opencode-py\config.json
py -3.8 -m opencode_py --init
py -3.8 -m opencode_py --no-tui
```

Linux:

```bash
python3.8 -m pip install -r requirements.txt
python3.8 -m opencode_py --init
OPENAI_API_KEY=sk-... python3.8 -m opencode_py
```

## Config file (api_key + base_url)

`~/.opencode-py/config.json` (`OPENCODE_PY_HOME` overrides dir for tests/portable use):

```json
{
  "base_url": "https://api.openai.com/v1",
  "api_key": "sk-...",
  "model": "gpt-4o-mini",
  "agent": "build"
}
```

Precedence: defaults < config file < env (`OPENAI_API_KEY/BASE_URL/MODEL`) < CLI flags.
File holds the secrets; env/CLI still override per-run (CI, shared Win2016 servers).

```bash
python -m opencode_py --init                      # prompt + save (api_key hidden)
python -m opencode_py --show-config               # path + masked key
python -m opencode_py --api-key sk-... --base-url http://localhost:11434/v1 \
  --model llama3 --save-config                    # non-interactive save
chmod 600 ~/.opencode-py/config.json  # auto-done on save where supported
```

## Usage

```bash
# interactive TUI (PyTermGUI if available, else plain console)
python -m opencode_py
python -m opencode_py --no-tui
python -m opencode_py --agent plan

# non-interactive (scripts / CI)
python -m opencode_py --print "list files and explain this repo"
echo "fix typo" | python -m opencode_py --print

# overrides
python -m opencode_py --model gpt-4o-mini --base-url http://localhost:11434/v1 --print "hi"
```

TUI keys/commands: type text + `Enter`, `/agent build|plan`, `/model <name>`, `/quit`.

## Scope vs original opencode

Ported (MVP): agent loop (build/plan), 7 tools (read/write/edit/bash/glob/grep/list_dir),
OpenAI-compatible `/chat/completions` via `urllib`, sessions (`~/.opencode-py/sessions/*.jsonl`),
PyTermGUI TUI + plain-console fallback, `--print` mode.

Not ported: 75+ providers, LSP, MCP, multi-session server, permission daemon,
desktop app, full TUI widgets. Add as needed — `opencode_py/llm.py` accepts any
OpenAI-compatible `base_url` (Ollama, LM Studio, vLLM, OpenRouter, Azure).

## Windows Server 2016 notes

- Prefer `Windows Terminal` or `conhost` with `chcp 65001`; legacy conhost has
  reduced ANSI/mouse — the app auto-falls back to plain console (`--no-tui`,
  `NO_COLOR=1`, `TERM=dumb`).
- No `pty`/`fcntl` used; `bash` tool uses `shell=True` + captured pipes.
- Python 3.8 syntax only: no `X|Y`, no `match`, no `tomllib`, `typing.List/Dict/Optional`.
