"""Local tools: read/write/edit/bash/glob/grep/list_dir.

All stdlib, Python 3.8 compatible, Windows-safe (no pty, no fcntl).
"""
import fnmatch
import glob as _glob
import os
import re
import subprocess
from typing import Any, Dict, List


def tool_read(path, offset=1, limit=2000, cwd=None):
    # type: (str, int, int, str) -> str
    p = _resolve(path, cwd)
    with open(p, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()
    total = len(lines)
    start = max(1, offset or 1) - 1
    end = start + (limit or 2000)
    chunk = lines[start:end]
    out = ["%d: %s" % (start + i + 1, l.rstrip("\n")) for i, l in enumerate(chunk)]
    return "\n".join(out) + ("\n... (%d total lines)" % total if end < total else "")


def tool_write(path, content, cwd=None):
    # type: (str, str, str) -> str
    p = _resolve(path, cwd)
    parent = os.path.dirname(os.path.abspath(p))
    if parent and not os.path.exists(parent):
        os.makedirs(parent)
    with open(p, "w", encoding="utf-8") as f:
        f.write(content)
    return "wrote %d bytes to %s" % (len(content), p)


def tool_edit(path, old_string, new_string, cwd=None):
    # type: (str, str, str, str) -> str
    p = _resolve(path, cwd)
    with open(p, "r", encoding="utf-8", errors="replace") as f:
        src = f.read()
    if old_string not in src:
        raise ValueError("old_string not found in %s" % p)
    if src.count(old_string) > 1:
        raise ValueError("old_string matches %d times; be more specific" % src.count(old_string))
    with open(p, "w", encoding="utf-8") as f:
        f.write(src.replace(old_string, new_string, 1))
    return "edited %s" % p


def tool_bash(command, cwd=None, timeout=60):
    # type: (str, str, int) -> str
    # Windows Server 2016: use shell=True, no pty. Capture combined output.
    try:
        proc = subprocess.run(
            command,
            shell=True,
            cwd=cwd or os.getcwd(),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout or 60,
            universal_newlines=True,
        )
        out = proc.stdout or ""
        if len(out) > 20000:
            out = out[:20000] + "\n... [truncated]"
        return "[exit %d]\n%s" % (proc.returncode, out)
    except subprocess.TimeoutExpired:
        return "[timeout after %ss]" % (timeout or 60)


def tool_glob(pattern, cwd=None):
    # type: (str, str) -> str
    base = cwd or os.getcwd()
    # support ** via glob module
    hits = _glob.glob(os.path.join(base, pattern), recursive=True)
    rel = [os.path.relpath(h, base) for h in hits[:200]]
    return "\n".join(rel) if rel else "(no matches)"


def tool_grep(pattern, include="*", cwd=None):
    # type: (str, str, str) -> str
    base = cwd or os.getcwd()
    rx = re.compile(pattern)
    out = []  # type: List[str]
    for root, _dirs, files in os.walk(base):
        # skip noisy dirs
        if ".git" in root.split(os.sep) or "__pycache__" in root.split(os.sep):
            continue
        for fn in files:
            if include and include != "*":
                if not fnmatch.fnmatch(fn, include):
                    continue
            fp = os.path.join(root, fn)
            try:
                with open(fp, "r", encoding="utf-8", errors="ignore") as f:
                    for i, line in enumerate(f, 1):
                        if rx.search(line):
                            rel = os.path.relpath(fp, base)
                            out.append("%s:%d: %s" % (rel, i, line.strip()[:300]))
                            if len(out) >= 200:
                                return "\n".join(out)
            except Exception:
                continue
    return "\n".join(out) if out else "(no matches)"


def tool_list_dir(path=".", cwd=None):
    # type: (str, str) -> str
    p = _resolve(path or ".", cwd)
    names = sorted(os.listdir(p))
    rows = []
    for n in names[:300]:
        fp = os.path.join(p, n)
        rows.append(n + "/" if os.path.isdir(fp) else n)
    return "\n".join(rows)


def _resolve(path, cwd):
    # type: (str, str) -> str
    if os.path.isabs(path):
        return path
    return os.path.join(cwd or os.getcwd(), path)


DISPATCH = {
    "read": tool_read,
    "write": tool_write,
    "edit": tool_edit,
    "bash": tool_bash,
    "glob": tool_glob,
    "grep": tool_grep,
    "list_dir": tool_list_dir,
}


def run_tool(name, args, cwd=None):
    # type: (str, Dict[str, Any], str) -> str
    fn = DISPATCH.get(name)
    if fn is None:
        return "unknown tool: %s" % name
    try:
        if name == "read":
            return fn(args.get("path", ""), int(args.get("offset", 1) or 1), int(args.get("limit", 2000) or 2000), cwd)
        if name == "write":
            return fn(args.get("path", ""), args.get("content", ""), cwd)
        if name == "edit":
            return fn(args.get("path", ""), args.get("old_string", ""), args.get("new_string", ""), cwd)
        if name == "bash":
            return fn(args.get("command", ""), cwd, int(args.get("timeout", 60) or 60))
        if name == "glob":
            return fn(args.get("pattern", ""), cwd)
        if name == "grep":
            return fn(args.get("pattern", ""), args.get("include", "*") or "*", cwd)
        if name == "list_dir":
            return fn(args.get("path", ".") or ".", cwd)
        return "unhandled tool"
    except Exception as e:
        return "tool error (%s): %s" % (name, e)
