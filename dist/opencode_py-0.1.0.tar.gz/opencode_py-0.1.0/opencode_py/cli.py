"""CLI entrypoint. Python 3.8 compatible (argparse only)."""
import argparse
import os
import sys

from . import __version__
from .agent import Agent
from .config import config_path, load_config, mask_key, save_config


def build_parser():
    # type: () -> argparse.ArgumentParser
    p = argparse.ArgumentParser(prog="opencode-py", description="Minimal opencode port for Python 3.8")
    p.add_argument("--version", action="store_true", help="print version")
    p.add_argument("--print", dest="do_print", action="store_true", help="non-interactive: print answer and exit")
    p.add_argument("--no-tui", action="store_true", help="force plain console even if PyTermGUI installed")
    p.add_argument("--model", default=None, help="override model")
    p.add_argument("--base-url", default=None, help="override OpenAI-compatible base URL")
    p.add_argument("--api-key", default=None, help="override API key (else from config file / OPENAI_API_KEY)")
    p.add_argument("--agent", default=None, choices=["build", "plan"], help="agent mode")
    p.add_argument("--cwd", default=None, help="working directory")
    p.add_argument("--session", default="default", help="session id")
    p.add_argument("--init", action="store_true", help="interactive setup: write base_url + api_key + model to config file and exit")
    p.add_argument("--save-config", action="store_true", help="persist effective --model/--base-url/--api-key/--agent to config file and exit")
    p.add_argument("--show-config", action="store_true", help="print config file path + masked values and exit")
    p.add_argument("prompt", nargs="*", help="prompt text (with --print)")
    return p


def run_init(cfg):
    # type: (dict) -> int
    # Interactive setup: prompts default to current effective values,
    # writes base_url + api_key + model + agent to config.json.
    try:
        from getpass import getpass
    except Exception:
        getpass = input  # type: ignore
    print("opencode-py setup (writes %s)" % config_path())
    cur_base = str(cfg.get("base_url", "") or "")
    cur_model = str(cfg.get("model", "") or "")
    cur_agent = str(cfg.get("agent", "") or "build")
    try:
        base = input("base_url [%s]: " % cur_base).strip() or cur_base
        model = input("model [%s]: " % cur_model).strip() or cur_model
        agent = input("agent [build|plan] [%s]: " % cur_agent).strip() or cur_agent
        try:
            key = getpass("api_key (hidden, Enter to keep %s): " % mask_key(str(cfg.get("api_key", "") or "")))
        except Exception:
            key = ""
        key = (key or "").strip()
    except (KeyboardInterrupt, EOFError):
        print("\ncancelled")
        return 1
    if agent not in ("build", "plan"):
        print("agent must be build|plan, keeping %s" % cur_agent)
        agent = cur_agent
    cfg["base_url"] = base
    cfg["model"] = model
    cfg["agent"] = agent
    if key:
        cfg["api_key"] = key
    path = save_config(cfg)
    print("saved to %s" % path)
    print("base_url: %s" % cfg.get("base_url", ""))
    print("api_key: %s" % mask_key(str(cfg.get("api_key", "") or "")))
    return 0


def main(argv=None):
    # type: (object) -> int
    args = build_parser().parse_args(argv)
    if getattr(args, "version", False):
        print(__version__)
        return 0
    cfg = load_config({
        "model": getattr(args, "model", None),
        "base_url": getattr(args, "base_url", None),
        "api_key": getattr(args, "api_key", None),
        "agent": getattr(args, "agent", None),
    })
    if getattr(args, "show_config", False):
        print("config: %s" % config_path())
        print("base_url: %s" % cfg.get("base_url", ""))
        print("api_key: %s" % mask_key(str(cfg.get("api_key", "") or "")))
        print("model: %s" % cfg.get("model", ""))
        print("agent: %s" % cfg.get("agent", ""))
        return 0
    if getattr(args, "save_config", False):
        path = save_config(cfg)
        print("saved to %s (api_key: %s)" % (path, mask_key(str(cfg.get("api_key", "") or ""))))
        return 0
    if getattr(args, "init", False):
        return run_init(cfg)
    cwd = getattr(args, "cwd", None) or os.getcwd()
    agent = Agent(cfg, cwd=cwd, session_id=getattr(args, "session", "default") or "default")

    if getattr(args, "do_print", False):
        prompt = " ".join(getattr(args, "prompt", []) or [])
        if not prompt:
            # read piped stdin (Windows-safe)
            if not sys.stdin.isatty():
                prompt = sys.stdin.read()
        if not prompt.strip():
            print("usage: opencode-py --print \"do X\"  (or pipe stdin)", file=sys.stderr)
            return 2
        ans = agent.ask(prompt)
        print(ans)
        return 0

    # interactive: prompt as initial message?
    initial = " ".join(getattr(args, "prompt", []) or []).strip()
    use_tui = not getattr(args, "no_tui", False)
    # conhost / NO_COLOR / dumb terminal -> prefer plain console
    term = (os.environ.get("TERM") or "").lower()
    if os.environ.get("NO_COLOR") or term in ("dumb", ""):
        # still allow TUI if explicitly wanted and available; default to console
        if sys.platform.startswith("win") and "WT_SESSION" not in os.environ:
            use_tui = False

    if use_tui:
        from .tui_ptg import run_ptg

        if initial:
            print(agent.ask(initial))
        return run_ptg(agent)
    from .console import run_console

    if initial:
        print(agent.ask(initial))
    return run_console(agent)
