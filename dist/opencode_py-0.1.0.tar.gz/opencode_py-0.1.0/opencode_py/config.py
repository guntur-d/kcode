"""Config handling. Python 3.8 compatible (no tomllib, no X|Y unions)."""
import json
import os
from typing import Any, Dict

DEFAULT_BASE_URL = "https://api.openai.com/v1"
DEFAULT_MODEL = "gpt-4o-mini"


def config_dir() -> str:
    # type: () -> str
    base = os.environ.get("OPENCODE_PY_HOME")
    if base:
        return base
    home = os.path.expanduser("~")
    return os.path.join(home, ".opencode-py")


def config_path() -> str:
    # type: () -> str
    return os.path.join(config_dir(), "config.json")


def load_config(overrides=None):
    # type: (Dict[str, Any]) -> Dict[str, Any]
    # Precedence: defaults < config file < env vars < CLI overrides.
    # This lets ~/.opencode-py/config.json hold api_key + base_url,
    # while env/CLI can still override per-run (CI, shared servers).
    cfg = {
        "base_url": DEFAULT_BASE_URL,
        "api_key": "",
        "model": DEFAULT_MODEL,
        "agent": "build",
    }  # type: Dict[str, Any]
    path = config_path()
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                file_cfg = json.load(f)  # type: Dict[str, Any]
            for k in ("base_url", "api_key", "model", "agent"):
                if k in file_cfg and file_cfg[k]:
                    cfg[k] = file_cfg[k]
        except Exception:
            pass
    # env overrides file
    if os.environ.get("OPENAI_BASE_URL"):
        cfg["base_url"] = os.environ.get("OPENAI_BASE_URL", "")
    if os.environ.get("OPENAI_API_KEY"):
        cfg["api_key"] = os.environ.get("OPENAI_API_KEY", "")
    if os.environ.get("OPENAI_MODEL"):
        cfg["model"] = os.environ.get("OPENAI_MODEL", "")
    if overrides:
        for k, v in overrides.items():
            if v is not None:
                cfg[k] = v
    # normalize base_url (strip trailing slash)
    if isinstance(cfg.get("base_url"), str):
        cfg["base_url"] = cfg["base_url"].rstrip("/")
    return cfg


def save_config(cfg):
    # type: (Dict[str, Any]) -> str
    # Persists api_key + base_url + model + agent to config.json.
    d = config_dir()
    if not os.path.exists(d):
        os.makedirs(d)
    path = config_path()
    safe = {
        "base_url": cfg.get("base_url", DEFAULT_BASE_URL),
        "api_key": cfg.get("api_key", ""),
        "model": cfg.get("model", DEFAULT_MODEL),
        "agent": cfg.get("agent", "build"),
    }  # type: Dict[str, Any]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(safe, f, indent=2)
    try:
        # restrict to owner where OS supports it (no-op on Win2016 conhost)
        os.chmod(path, 0o600)
    except Exception:
        pass
    return path


def mask_key(key):
    # type: (str) -> str
    if not key:
        return "(not set)"
    if len(key) <= 8:
        return "****"
    return key[:4] + "..." + key[-4:]
