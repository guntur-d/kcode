"""Plain-console fallback REPL (works everywhere, incl. legacy conhost)."""
import sys


def run_console(agent, stdin=None, stdout=None):
    # type: (object, object, object) -> int
    inp = stdin or sys.stdin
    out = stdout or sys.stdout
    out.write("opencode-py [%s/%s] (type /help, /quit)\n" % (
        getattr(agent, "model", "?"), getattr(agent, "agent", "build")))
    out.flush()
    while True:
        try:
            out.write("\n> ")
            out.flush()
            line = inp.readline()
            if not line:
                break
            text = line.strip()
            if not text:
                continue
            if text in ("/quit", "/exit", ":q"):
                break
            if text in ("/help", "/?"):
                out.write("/agent build|plan  /model <name>  /quit\n")
                continue
            if text.startswith("/agent"):
                parts = text.split()
                if len(parts) == 2:
                    agent.set_agent(parts[1].strip())  # type: ignore[attr-defined]
                    out.write("agent=%s\n" % getattr(agent, "agent", "?"))
                continue
            if text.startswith("/model"):
                parts = text.split(None, 1)
                if len(parts) == 2:
                    agent.model = parts[1].strip()  # type: ignore[attr-defined]
                    out.write("model=%s\n" % getattr(agent, "model", "?"))
                continue

            def _on_tool(name, args, result):
                # type: (str, dict, str) -> None
                out.write("\n[tool %s] %s\n" % (name, str(result)[:2000]))

            out.write("...\n")
            out.flush()
            ans = agent.ask(text, on_tool=_on_tool)  # type: ignore[attr-defined]
            out.write("\n%s\n" % ans)
            out.flush()
        except KeyboardInterrupt:
            break
        except Exception as e:
            out.write("\n[error] %s\n" % e)
            out.flush()
    return 0
